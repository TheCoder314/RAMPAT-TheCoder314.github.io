R.A.M.P.A.T. printable parts (STL, millimetres)

One file per physical part. Left (L) and right (R) parts are mirrored,
so print each file once. parts-list.csv maps each file to its Onshape name.
Material: LW-PETG, gyroid infill.
  Fuselage shells (nose cone, front, center): 1 wall loop, 3% infill
  Wings (wing panels, ailerons):              1 wall loop, 5% infill
  Connectors (joiners, mounts, root plates):  3 wall loops, 20% infill
  Everything else:                            2 wall loops, 20% infill
The print_profile column in parts-list.csv gives the profile for each file.
Orient parts in your slicer before printing.

License: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/)
