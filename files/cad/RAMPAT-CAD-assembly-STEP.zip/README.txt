R.A.M.P.A.T. full assembly (STEP AP214, millimetres)

Open in Onshape, Fusion, SolidWorks or FreeCAD to modify the design.
The assembly includes purchased hardware (motors, servos, screws, carbon tubes)
for reference. Only the parts in the STL pack need printing.

License: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/)
