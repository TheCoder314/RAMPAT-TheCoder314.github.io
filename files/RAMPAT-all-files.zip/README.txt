R.A.M.P.A.T. complete file set

CAD/STEP   full assembly for modification
CAD/STL    individual parts for printing
PCB        flight controller Gerber ZIP; upload it unchanged to your PCB fab
           (4 layers, 1.6 mm, HASL)

License: CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/)
